Creator Dost AI — Real AI version

This version uses a Netlify Function to call Google's Gemini API. The API key is NOT stored in the HTML.

Important setup:
1. Deploy this folder through a GitHub repository connected to Netlify (manual drag-and-drop static deploy does not reliably deploy serverless functions).
2. In Google AI Studio, create a Gemini API key.
3. In Netlify: Site configuration / Environment variables, add GEMINI_API_KEY with the key value.
4. Redeploy the site.
5. Never paste the API key into index.html or share it publicly. Check Google AI Studio's current availability, usage limits, and billing terms for your account/region.

The site will show a helpful error until the environment variable is configured.
